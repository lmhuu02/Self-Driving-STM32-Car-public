
#include "stm32f4xx.h"

void GPIO_Setup(void);
void TIM2_Init(void);
void TIM4_ms_Delay(uint32_t delay);

void GPIO_Setup(){
    RCC->AHB1ENR |= 1; //Enable GPIOA clock
    GPIOA->AFR[0] |= 0x00100000; // Select the PA5 pin in alternate function mode
    GPIOA->MODER |= 0x00000800; //Set the PA5 pin alternate function
}
void TIM2_Setup(){
    RCC->APB1ENR |=1;
    TIM2->PSC = 4; //Setting the clock frequency to 1MHz.//16-1
    TIM2->ARR = 64000-1; // Total period of the timer
    TIM2->CNT = 0;

    TIM2->CCMR1 = 0x0060; //PWM mode for the timer
    TIM2->CCER |= 1; //Enable channel 1 as output
    TIM2->CCR1 = 500; // Pulse width for PWM
}
void TIM4_ms_Delay(uint32_t delay){
    RCC->APB1ENR |= 1<<2; //Start the clock for the timer peripheral
    TIM4->PSC = 16000-1; //Setting the clock frequency to 1kHz.
    TIM4->ARR = (delay); // Total period of the timer
    TIM4->CNT = 0;
    TIM4->CR1 |= 1; //Start the Timer
    while(!(TIM4->SR & TIM_SR_UIF)){} //Polling the update interrupt flag
    TIM4->SR &= ~(0x0001); //Reset the update interrupt flag
}
//void delay(unsigned int delay){
//	unsigned int i=0;
//	for (i=0; i<delay; i++);
//}

void delay(int ms)

{

int i;

for(; ms>0 ;ms--)

{

for(i =0; i<3195;i++);

}

}

long map(long x, long in_min, long in_max, long out_min, long out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void servo_write(uint8_t angle)
	{

	if(angle<0){angle=0;}
	if(angle>180){angle=180;}

TIM2->CCR1=map (angle,0,180,2500,7000);
	}
int main(void)
{
	int pos;
		RCC->CFGR |= 0<<10; // set APB1 = 16 MHz
	    GPIO_Setup();
	    TIM2_Setup();
	    TIM2->CR1 |= 1;
//	    TIM2->CCR1 = 500;
//	    delay(40000);
//	    TIM2->CCR1 = 0;
//	    TIM4_ms_Delay(500);

	    while(1){

////	        if(TIM2->CCR1 < 2500){
////	            TIM2->CCR1 = TIM2->CCR1 + 50;
////	            TIM4_ms_Delay(50);
////	        }
////	        else{
//	            TIM2->CCR1 = 500;
////	            TIM4_ms_Delay(500);
//	            delay(1000);
//	            TIM2->CCR1 = 300;
//	            delay(40000);
////	            TIM4_ms_Delay(500);
////	        }
	    	  for (pos = 0; pos <= 180; pos += 1) { // goes from 0 degrees to 180 degrees
	    	    // in steps of 1 degree
	    	    servo_write(pos);              // tell servo to go to position in variable 'pos'
	    	    delay(15);                       // waits 15ms for the servo to reach the position
	    	  }
	    	  for (pos = 180; pos >= 0; pos -= 1) { // goes from 180 degrees to 0 degrees
	    	    servo_write(pos);              // tell servo to go to position in variable 'pos'
	    	    delay(15);                       // waits 15ms for the servo to reach the position
	    	  }

	   }
}
