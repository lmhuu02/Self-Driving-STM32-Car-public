/*
 * Distance can be calculated by using the following formula :- range = high level time * velocity (340m/s) / 2
We can also use uS / 58 = Distance in cm or uS / 148 = distance in inch
It is recommended to wait for at least 60ms before starting the operation again.
 */

#include"stm32f4xx.h"
#include"stm32f4xx_gpio.h"
#include"stm32f4xx_rcc.h"
#include"stm32f4xx_usart.h"
#include "misc.h"
#include "stm32f4xx_syscfg.h"
#include "stm32f4xx_exti.h"
#include <stm32f4xx_tim.h>

//#include <stdio.h>
//#include <string.h>


void setup_PA3(){
		 GPIO_InitTypeDef  GPIO_InitStructure;
		 /* Enable the GPIO_LED Clock */
		  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

		  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
		  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT ;
		  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
		  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_100MHz;
		  GPIO_Init(GPIOA, &GPIO_InitStructure);
}

unsigned int Flag_Raising_Falling = 0; //=0 echo high; =1 echo low
uint32_t  Num_CLK=0;
unsigned char st[100];


void EXTI_PA4_Config(void)
{
  EXTI_InitTypeDef   EXTI_InitStructure;
  GPIO_InitTypeDef   GPIO_InitStructure;
  NVIC_InitTypeDef   NVIC_InitStructure;

  /* Enable GPIOA clock */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

  /* Configure PA0 pin as input floating */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  /* Enable SYSCFG clock */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);

  /* Connect EXTI0 Line to PA0 pin */
  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource4);

  /* Configure EXTI0 line */
  EXTI_InitStructure.EXTI_Line = EXTI_Line4;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);

  /* Enable and set EXTI0 Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}

void delay(uint16_t time){
	while(time--);
}
void delayMS(uint16_t time){
	uint32_t i;
	while(time--){
		for (i=0;i<1000;i++); //1s
	}
}

//void usart_setup(void)
//{
//
//	//USART1: PA9 - Tx (STM32) <-> Rx (USB TTL) ; PA10-Rx (STM32) <-> Tx (USB TTL)
//
//	USART_InitTypeDef USART1_S;
//
//	GPIO_InitTypeDef     GPIO_InitStruct;
//
//	// Enable clock for GPIOA
//	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
//
//	/**
//	* Tell pins PA9 and PA10 which alternating function you will use
//	* @important Make sure, these lines are before pins configuration!
//	*/
//	GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_USART1);
//	GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_USART1);
//	// Initialize pins as alternating function
//	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
//	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
//	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
//	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
//	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
//	GPIO_Init(GPIOA, &GPIO_InitStruct);
//
//
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
//
//  USART1_S.USART_BaudRate = 9600;
//  USART1_S.USART_WordLength = USART_WordLength_8b;
//  USART1_S.USART_StopBits = USART_StopBits_1;
//  USART1_S.USART_Parity = USART_Parity_No;
//  USART1_S.USART_HardwareFlowControl = USART_HardwareFlowControl_None; //ko dung CTS/RTS
//  USART1_S.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
//  USART_Init(USART1, &USART1_S);
//
//  USART_Cmd(USART1,ENABLE);
//}
//void Send_Char( char data)
//{
//		// Doi cho den khi dem phat rong
//	  while(USART_GetFlagStatus(USART1, USART_FLAG_TXE)==RESET);
//	  USART_SendData(USART1,data);
//
//}
//
//void Send_String(char str[100]){ //char * x; char x[100] ;
//
//	int i;
//	for (i=0;i<strlen(str); i++){
//		Send_Char(str[i]);
//
//	}
//}

//unsigned char  Received_Char()
//{
//	unsigned char ch;
//	// Doi cho den khi dem nhan co du lieu
//	while((USART1->ISR & USART_ISR_RXNE) == RESET);
//	ch = (char) USART1->RDR;
//	return ch;
//}
//
//
//
//void Received_String()
//{
//	//st[0]='\0' ;
//	int i=0;
//	while (1){
//	st[i]=Received_Char();
//
//	if ((st[i] =='x'))  //'\r', '\n' - ki tu xuong dong
//		break;
//	i++;
//	}
//
//}

void usart_setup(void)
{
	// USART1: PA2 - Tx; PA3-Rx
	USART_InitTypeDef USART1_S;
	GPIO_InitTypeDef GPIOA_S ;

	RCC_AHB2PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

	GPIO_PinAFConfig(GPIOA, GPIO_PinSource2,GPIO_AF_USART2);
//	GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART1);

	GPIOA_S.GPIO_Pin    = GPIO_Pin_2 ;//| GPIO_Pin_3;
	GPIOA_S.GPIO_Speed = GPIO_Speed_50MHz;
	GPIOA_S.GPIO_Mode    = GPIO_Mode_AF;
	GPIOA_S.GPIO_OType = GPIO_OType_PP;
	GPIOA_S.GPIO_PuPd    = GPIO_PuPd_UP;
	GPIO_Init(GPIOA, &GPIOA_S);

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);

	USART1_S.USART_BaudRate = 115200;
	USART1_S.USART_WordLength = USART_WordLength_8b;
	USART1_S.USART_StopBits = USART_StopBits_1;
	USART1_S.USART_Parity = USART_Parity_No;
	USART1_S.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART1_S.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART2, &USART1_S);
	USART_Cmd(USART2,ENABLE);
}
//
void USART_Send_Char(unsigned char data)
{
	  while(USART_GetFlagStatus(USART2, USART_FLAG_TXE)==RESET);
	  USART_SendData(USART2,data);
}

void Send_String(char str[100]){

	int i;
	for (i=0;i<strlen(str); i++){
		USART_Send_Char(str[i]);
	}
}
void TIM3_Config (void)
 {
// NVIC_InitTypeDef NVIC_InitStructure;
 TIM_TimeBaseInitTypeDef   TIM_TimeBaseStructure;

 RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
 TIM_TimeBaseStructure.TIM_Prescaler = 0;// he so chia toc do counter - AHB/1 = 1MHz
 TIM_TimeBaseStructure.TIM_Period = 60000; //autoreload ARR
 TIM_TimeBaseStructure.TIM_ClockDivision = 0;
 TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

 TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

// TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);  //cho phep ngat timer

// TIM_Cmd(TIM3, ENABLE); //cho phep timer

// NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
// NVIC_InitStructure.NVIC_IRQChannelPriority=0;
// NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
// NVIC_Init(&NVIC_InitStructure);

}
//chuong trinh con phuc vu ngat
void EXTI4_IRQHandler(void)
{
  //PA4
  if(EXTI_GetITStatus(EXTI_Line4) != RESET)
  {
	 if ( Flag_Raising_Falling ==0){
    /* Toggle LED8 */
		 GPIOC->ODR=(uint16_t)0x0100;
		 Flag_Raising_Falling =1;
		 Num_CLK=0;
		 TIM3->CNT=0;
		 TIM_Cmd(TIM3, ENABLE);
	 }else{
	 if ( Flag_Raising_Falling ==1){
	     /* Toggle LED8 */
	 		 GPIOC->ODR=(uint16_t)0x0300;
	 		 /* Clear the EXTI line 0 pending bit */
	 		Num_CLK=TIM3->CNT;
	 		TIM_Cmd(TIM3, DISABLE);
//	 		Distance = Num_CLK*340/50;
	 		sprintf(st, "Distance: %d cm\r\n", Num_CLK);// (elapsed time * speed of sound (340 m / s)) / 100 / 2
	 		// S = V*t = van toc khong khi * t (doi xung ra giay)
//	 		st="ok";
	 		Send_String(st);
	 		Flag_Raising_Falling =0;
	 }
	 }
	 EXTI_ClearITPendingBit(EXTI_Line4);
}
}
int main(void)
{
	uint16_t  time1=0, time2=0, i;
	unsigned int  numTicks=0;
//	 char st[100], ch;
//	float Distance = 0.0;
//	char MSG[25] = {0};

	RCC->CFGR |= ((uint16_t)0xA<<4); //AHB 1MHz ~ 1 xung / 1us --> lay Timer 1MHz
//	setup_LED();
	setup_PA3();
//	setup_PA4();
	EXTI_PA4_Config();
	usart_setup();
//	GPIOA->ODR &=~(uint16_t)0xFFFF;
	TIM3_Config();
    while(1)
    {
    					Send_String("Reading distance ...\r\n");
    					TIM3->CNT=0;
    					Flag_Raising_Falling ==0;

    					//read sensor
    		    		GPIOA->ODR &= ~((uint16_t)0x8); 	//PA3=Trig=0
    		            delay(32);  //toc do vi dieu khien 8MHz (F0), 1us ~ 8 xung -> 2us ~ 16 xung; tren F4 (16MHz) 2us = 32 xung

    		            GPIOA->ODR |= (uint16_t)0x8; 		//PA3=trig=1;
    		            delay(160); //  delay 10us (F0); delay(160) (F4)
    		            GPIOA->ODR &= ~((uint16_t)0x8); 	//trig=0;

//    		            sprintf(st, "Distance: %d cm\r\n", numTicks);
////
//    		            Send_String(st);
//    		            		Send_String("\n ");
//    		            		DIS = (unsigned int)numTicks/148;

    		            delayMS(3000);
    	}
    }
