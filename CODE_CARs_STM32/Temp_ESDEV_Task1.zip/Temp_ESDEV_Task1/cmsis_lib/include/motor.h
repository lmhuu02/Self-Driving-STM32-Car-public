#include"stm32f4xx.h"


void ENBLE_Motor(){
	RCC->CFGR |= 0<<10;   // set APB1 = 16 MHz
	RCC->AHB1ENR |= ((uint32_t)0x00000001);
			  // PA0
	GPIOA->MODER = (GPIOA->MODER & ~((uint32_t)(0x3 << 0))) | (uint32_t)(0x1 << 0);
	GPIOA->OTYPER &= ~(uint16_t)(0x1 << 0) ;
	GPIOA->PUPDR &= ~(uint32_t)(0x3 << 0) ;
	GPIOA->OSPEEDR = (GPIOA->OSPEEDR & ~((uint32_t)(0x3 << 0))) | (uint32_t)(0x1 << 0);
			  // PA1
	GPIOA->MODER = (GPIOA->MODER & ~((uint32_t)(0x3 << 2))) | (uint32_t)(0x1 << 2);
	GPIOA->OTYPER &= ~(uint16_t)(0x1 << 1) ;
	GPIOA->PUPDR &= ~(uint32_t)(0x3 << 2) ;
	GPIOA->OSPEEDR = (GPIOA->OSPEEDR & ~((uint32_t)(0x3 << 2))) | (uint32_t)(0x1 << 2);
}

void Turn_motor(uint16_t time){
	while(time){
	GPIOA->ODR |=(uint16_t)0x001;
	GPIOA->ODR |=(uint16_t)0x002;
	delay(300);
	GPIOA->ODR &=~(uint16_t)0x001;
	GPIOA->ODR &=~(uint16_t)0x002;
	delay(1000);
	time--;
	}
}
