
#include"stm32f4xx.h"
#include"motor.h"

//#define ....

//khai bao ham Ham
void delay(uint16_t time);

void tien();

int main(void)
{
	ENBLE_Motor();
    while(1)
    {
    	tien();
    	Turn_motor(10); //chay 10us

    }
}
void delay(uint16_t time){
	while(time--);

}
void tien(){
	//dieu khien robot tien
}
